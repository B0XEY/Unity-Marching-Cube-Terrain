using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AboveCamera : MonoBehaviour
{
    public static AboveCamera Instance { get; private set; }
    
    
    [Header("Camera")]
    [SerializeField] private bool useOverheadCamera;
    [Space]
    [SerializeField, ConditionalHide("useOverheadCamera", true)] private GameObject Cameraobj;

    private float x;
    private float y;
    private float z;

    private void Awake() {
        if (Instance != null) {
            Destroy(Instance);
            Instance = null;
        }
        Instance = this;
    }


    void Start() {
        if (useOverheadCamera) {
            MoveCamera();
        }
    }
    
    
    public void MoveCamera() {
        if (!useOverheadCamera || Cameraobj == null) return;
        x = PositionMath.CalculateX();
        y = CalculateY();
        z = PositionMath.CalculateZ();
        
        transform.position = new Vector3(x, y, z);
        transform.rotation = Quaternion.Euler(new Vector3(90,0,0));
    }

    float CalculateY() {
        float temp = 62.5f;
        
        if (x <= 64) temp = 125;
        else if (x <= 128) temp = 250;
        else if (x <= 256) temp = 500;
        else if (x <= 512) temp = 1000;
        else if (x <= 1024) temp = 2000;
        else if (x <= 2048) temp = 4000;
        else temp = 8000;

        return temp;
    }

}
