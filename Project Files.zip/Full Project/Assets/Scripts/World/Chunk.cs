using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chunk : MonoBehaviour
{
    [HideInInspector] public List<Vector3> vertices = new List<Vector3>();
    private List<int> triangles = new List<int>();
    private List<Vector2> uvs = new List<Vector2>();
    
    [HideInInspector] public TerrainPoint[,,] terrainMap;
    
    public GameObject chuckObject;
    
    bool smoothTerrain;
    bool flatShading;


    private MeshFilter meshFilter;
    private MeshCollider meshCollider;
    private MeshRenderer meshRenderer;
    

    private Vector3Int chunkPosition;
    private World.NoiseType noiseType;
    
    private float heightSmooth;
    private float heightMult;

    private AnimationCurve heightCurve;

    private bool useFallOff;
    
    int chunkWidth { get { return World.chunkWidthS; } }
    int chunckHeight { get { return World.chunkHeightS; } }
    float terrainSurface { get { return World.terrainSurfaceS; } }
    

    public Chunk (Vector3Int _position,float smooth, float mult, World.NoiseType type, bool smoothTerrain, bool flat , bool island, AnimationCurve _heightCurve)
    {
        chuckObject = new GameObject();
        chuckObject.name = string.Format("Chunk {0}, {1}", _position.x, _position.z);
        this.smoothTerrain = smoothTerrain;
        flatShading = flat;
        noiseType = type;        
        chunkPosition = _position;
        chuckObject.transform.position = chunkPosition;
        useFallOff = island;
        heightCurve = _heightCurve;

        heightSmooth = smooth;
        heightMult = mult;
        
        meshFilter = chuckObject.AddComponent<MeshFilter>();
        meshCollider = chuckObject.AddComponent<MeshCollider>();
        meshRenderer = chuckObject.AddComponent<MeshRenderer>();

        meshRenderer.material = Resources.Load<Material>("Materials/World Material");

        chuckObject.transform.tag = "World";
        chuckObject.layer = 3;
        
        terrainMap = new TerrainPoint[chunkWidth + 1, chunckHeight + 1, chunkWidth + 1];
            
        ClearMeshData();

        TerrainMap();
        CreateMeshData();
        BuildMesh();
    }

    //Mesh Generation
    void ClearMeshData() {
        vertices.Clear();
        triangles.Clear();
        uvs.Clear();
    }

    void BuildMesh() {
        Mesh mesh = new Mesh();
        mesh.vertices = vertices.ToArray();
        mesh.triangles = triangles.ToArray();
        mesh.normals = CalculateNormals();
        mesh.uv = uvs.ToArray();
        meshFilter.mesh = mesh;
        meshCollider.sharedMesh = mesh;
    }

    Vector3[] CalculateNormals() {
        Vector3[] vertexNormals = new Vector3[vertices.Count];
        int triangleCont = triangles.Count / 3;
        for (int i = 0; i < triangleCont; i++) {
            int normalTriangleIndex = i * 3;
            int vertexIndexA = triangles[normalTriangleIndex];
            int vertexIndexB = triangles[normalTriangleIndex + 1];
            int vertexIndexC = triangles[normalTriangleIndex + 2];

            Vector3 triangleNormal = SurfaceNormal(vertexIndexA, vertexIndexB, vertexIndexC);
            vertexNormals[vertexIndexA] += triangleNormal;
            vertexNormals[vertexIndexB] += triangleNormal;
            vertexNormals[vertexIndexC] += triangleNormal;
        }

        for (int i = 0; i < vertexNormals.Length; i++) {
            vertexNormals[i].Normalize();
        }

        return vertexNormals;
    }

    Vector3 SurfaceNormal(int indexA, int indexB, int indexC) {
        Vector3 pointA = vertices[indexA];
        Vector3 pointB = vertices[indexB];
        Vector3 pointC= vertices[indexC];

        Vector3 sideAB = pointB - pointA;
        Vector3 sideAC = pointC - pointA;
        
        return Vector3.Cross(sideAB, sideAC).normalized;
    }

    int GetCubeConfig(float[] cube) {
        int config = 0;
        for (int i = 0; i < 8; i++) {
            if (cube[i] > terrainSurface) {
                config |= 1 << i;
            }
        }

        return config;
    }

    void MarchCube(Vector3Int position)
    {
        float[] cube = new float[8];
        for (int i = 0; i < 8; i++) {
            cube[i] = SampleTerrain(position + Tables.CornerTable[i]);
        }
        
        int configIndex = GetCubeConfig(cube);
        
        if (configIndex == 0 || configIndex == 255)
            return;

        int edgeIndex = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                int indice = Tables.TriangleTable[configIndex, edgeIndex];
                
                if (indice == -1)
                    return;

                Vector3 vert1 = position + Tables.CornerTable[Tables.EdgeIndexes[indice, 0]];
                Vector3 vert2 = position + Tables.CornerTable[Tables.EdgeIndexes[indice, 1]];

                Vector3 vertPosition;
                
                if (smoothTerrain) {
                    float vert1Sample = cube[Tables.EdgeIndexes[indice, 0]];
                    float vert2Sample = cube[Tables.EdgeIndexes[indice, 1]];

                    float difference = vert2Sample - vert1Sample;
                    if (difference == 0)
                        difference = terrainSurface;
                    else
                        difference = (terrainSurface - vert1Sample) / difference;

                    vertPosition = vert1 + ((vert2 - vert1) * difference);

                }else {
                    vertPosition = (vert1 + vert2) / 2f;
                }
                
                //Set Texture For Point - Biomes Only
                if (WorldVisuals.useBiomes && Application.isPlaying) {
                    terrainMap[position.x, position.y, position.z].textureID =
                        WorldVisuals.Instance.GetTextureForPoint(vertPosition);
                }

                if (flatShading)
                {
                    vertices.Add(vertPosition);
                    uvs.Add(new Vector2(terrainMap[position.x, position.y, position.z].textureID, 0));
                    triangles.Add(vertices.Count - 1);
                }else {
                    triangles.Add(VertForIndice(vertPosition, position));
                }

                edgeIndex++;
            }
        }
    }

    void TerrainMap() {
        for (int x = 0; x <= chunkWidth; x++) {
            for (int y = 0; y <= chunckHeight; y++) {
                for (int z = 0; z <= chunkWidth; z++) {
                    float thisHeight = heightCurve.Evaluate(World._noiseMap[x + chunkPosition.x, z + chunkPosition.z]);
                    
                    if (thisHeight >= chunckHeight) thisHeight = chunckHeight - .1f;
                    
                    thisHeight = noiseType == World.NoiseType.Simple
                        ? thisHeight / heightSmooth
                        : thisHeight * heightMult;


                    terrainMap[x, y, z] = new TerrainPoint((float)y - thisHeight, 0);
                }
            }
        }
    }

    public void CreateMeshData() {
        for (int x = 0; x < chunkWidth; x++) {
            for (int y = 0; y < chunckHeight; y++) {
                for (int z = 0; z < chunkWidth; z++) {
                    MarchCube(new Vector3Int(x,y,z));
                }
            }
        }
    }


    float SampleTerrain(Vector3Int point) {
        return terrainMap[point.x, point.y, point.z].dstToSurface;
    }

    public void PlaceTerrain(Vector3 pos) {
        Vector3Int v3Int = new Vector3Int(Mathf.CeilToInt(pos.x), Mathf.CeilToInt(pos.y), Mathf.CeilToInt(pos.z));
        terrainMap[v3Int.x, v3Int.y, v3Int.z].dstToSurface = 0f;
        CreateMeshData();
    }
    
    public void RemoveTerrain(Vector3 pos) {
        Vector3Int v3Int = new Vector3Int(Mathf.FloorToInt(pos.x), Mathf.FloorToInt(pos.y), Mathf.FloorToInt(pos.z));
        terrainMap[v3Int.x, v3Int.y, v3Int.z].dstToSurface = 1f;
        CreateMeshData();
    }

    private float strength = 2f;
    private float radius = 2.5f;
    
    
    public void Terraform(Vector3 point, bool placing) {
        World.Instance.TerraformChunk(point, strength, radius, placing);
    }

    int VertForIndice(Vector3 vert, Vector3Int point)
    {
        for (int i = 0; i < vertices.Count; i++) {
            if (vertices[i] == vert)
                return i;
        }
        
        vertices.Add(vert);
        uvs.Add(new Vector2(terrainMap[point.x, point.y, point.z].textureID, 0));
        return vertices.Count - 1;
    }
}
