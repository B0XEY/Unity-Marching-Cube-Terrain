using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEditor;
using Color = UnityEngine.Color;
using Random = UnityEngine.Random;

public class World : MonoBehaviour
{
    public static World Instance { get; private set; }
    

    [HideInInspector]public bool Texture;
    [HideInInspector]public bool Marching;

    
    public enum GenerationType {
        Texture,
        Marching
    }
    private GenerationType oldgenType;
    enum GenerationMethod {
        Instantly,
        Enumerator
    }

    [Header("Generation")] 
    public GenerationType genType = GenerationType.Texture;
    [SerializeField, ConditionalHide("Marching", true),  Tooltip("I recommend 'Enumerator' for map's over 32 chunks")] GenerationMethod genMethod = GenerationMethod.Instantly;
    [Space(5f)]
    [SerializeField] public int WorldSizeInChunks = 16;
    [Space(5f)]
    [SerializeField] public int chunkWidth = 16;
    [SerializeField] public int chunkHeight = 16;
    [Space]
    [SerializeField, ConditionalHide("Texture", true)] private GameObject texturePlane;
    [SerializeField, ConditionalHide("Marching", true)] public Transform chunkHolder;
    [Space]
    [SerializeField, ConditionalHide("Texture", true)] private bool autoUpdate;
    [SerializeField, ConditionalHide("Marching", true)] public bool smoothTerrain = false;
    [SerializeField, ConditionalHide("Marching", true)] public bool flatShading = true;
    [Space] 
    [SerializeField, ConditionalHide("Marching", true)] public float BaseHeight = 4;
    [SerializeField, ConditionalHide("Marching", true)] public float HeightRange = 11;
    [HideInInspector] public float terrainSurface = 0;

    public static int chunkWidthS;
    public static int chunkHeightS;
    public static int WorldSizeInChunksS;
    public static float terrainSurfaceS;
    
    public static float BaseHeightS;
    public static float HeightRangeS;
    
    
    private MeshFilter meshFilter;
    private MeshCollider meshCollider;
    
    [HideInInspector] public bool Simple;
    [HideInInspector] public bool Complex;
    
    public enum NoiseType {
        Simple,
        Complex
    }
    private NoiseType oldnoiseType;

    [Space, Header("Noise")] 
    [SerializeField] private NoiseType noiseType = NoiseType.Simple;
    [Space]
    [SerializeField] private PerlinNoise.NormalizeMode normalizeType = PerlinNoise.NormalizeMode.Local;
    [SerializeField] private float normalizeScale = .05f;
    [Space]
    [SerializeField, Range(1.01f, 850)] private float noiseScale = 50;
    [SerializeField] private bool randomNoiseOffset;
    [SerializeField] private Vector2 noiseOffset;
    [Space(5f)] 
    [SerializeField] private int seed = 0;
    [SerializeField] private bool useFallOff;
    [ConditionalHide("useFallOff", true), Range(1,5)] public float falloffCenterStrength = 1f;
    [ConditionalHide("useFallOff", true), Range(1,5)] public float falloffEdge = 1f;
    [Space(10f)]
    [SerializeField] private AnimationCurve heightCurve;
    [SerializeField, ConditionalHide("Simple", true)] private float heightSmooth = 2;
    [SerializeField, ConditionalHide("Complex", true)] private float heightMult = 10;
    [Space]
    [SerializeField, ConditionalHide("Complex", true), Range(1,8)] private int octaves = 1;
    [SerializeField, ConditionalHide("Complex", true), Range(0,1)] private float persistence = .5f;
    [SerializeField, ConditionalHide("Complex", true), Range(0.1f, 5)] private float lacunarity = 2f;
    [SerializeField, ConditionalHide("Complex", true), Range(1,15)] private float amplitude = 1f;
    [SerializeField, ConditionalHide("Complex", true), Range(1,15)] private float frequency = 1f;

    [Space, Header("Debug")] 
    public bool doDebug;
    [Space]
    [SerializeField, ConditionalHide("doDebug", true)] TMP_Text _chunkLoadTimeText;

    public static float[,] _falloffMap;
    public static float[,] _noiseMap;

    private Dictionary<Vector3Int, Chunk> chunks = new Dictionary<Vector3Int, Chunk>();
    
    public static bool MapGenerated;

    private void Awake() {
        if (Instance != null) {
            Destroy(Instance);
            Instance = null;
        }
        Instance = this;
        
        
        
        chunkHeightS = chunkHeight;
        chunkWidthS = chunkWidth;
        terrainSurfaceS = terrainSurface;
        WorldSizeInChunksS = WorldSizeInChunks;
        BaseHeightS = BaseHeight;
        HeightRangeS = HeightRange;
        
        //Can Remove
        if (WorldSizeInChunksS > 16 && genMethod != GenerationMethod.Enumerator) genMethod = GenerationMethod.Enumerator;
    }

    private void Start()
    {
        if (randomNoiseOffset)noiseOffset = new Vector2(
            Random.Range(-999999, 999999),
            Random.Range(-999999, 999999)
        );
        GenerateWorld();
    }

    public void GenerateWorld() {
        MapGenerated = false;
        if (gameObject.GetComponent<ObjectPlacer>().enabled)ObjectPlacer.startedSpawn = false;
        if (gameObject.GetComponent<ObjectPlacer>().enabled)ObjectPlacer.TreesSpawned = false;
        
        
        chunkHeightS = chunkHeight;
        chunkWidthS = chunkWidth;
        terrainSurfaceS = terrainSurface;
        WorldSizeInChunksS = WorldSizeInChunks;
        BaseHeightS = BaseHeight;
        HeightRangeS = HeightRange;
        
        if (Application.isPlaying) AboveCamera.Instance.MoveCamera();
        
        if (_chunkLoadTimeText != null) _chunkLoadTimeText.gameObject.SetActive(doDebug);
        
        //Noise
        _falloffMap = PerlinNoise.GenerateFalloffMap(WorldSizeInChunks * chunkWidth, WorldSizeInChunks  * chunkWidth, falloffCenterStrength, falloffEdge);
        
        if (noiseType == NoiseType.Simple)
            _noiseMap = PerlinNoise.GenerateSimpleNoiseMap(WorldSizeInChunks * chunkWidth, WorldSizeInChunks * chunkWidth,
                noiseScale, seed, noiseOffset, true, HeightRange, BaseHeight, normalizeType, normalizeScale);
        else if (noiseType == NoiseType.Complex)
            _noiseMap = PerlinNoise.GenerateComplexNoiseMap(WorldSizeInChunks * chunkWidth, WorldSizeInChunks * chunkWidth, noiseScale, seed,
                amplitude, frequency, octaves, persistence,
                lacunarity, noiseOffset, true, HeightRange, BaseHeight, normalizeType, normalizeScale);

        if (useFallOff) {
            for (int x = 0; x <= WorldSizeInChunks * chunkWidth; x++) {
                for (int y = 0; y < WorldSizeInChunks * chunkWidth; y++) {
                    _noiseMap[x, y] -= _falloffMap[x, y];
                    _noiseMap[x, WorldSizeInChunks * chunkWidth] -= _falloffMap[x, y];
                }
            }
        }

        //Generation
        if (genType == GenerationType.Texture) {
            if (texturePlane == null) {
                Debug.LogError("The 'texturePlane' is not assigned!");
                return;
            }
            Renderer _r = texturePlane.GetComponent<Renderer>();
            GenerateTexture(_r);
        }
        if (genType == GenerationType.Marching) {
            if (chunkHolder == null) {
                Debug.LogError("The 'chunkHolder' is not assigned!");
                return;
            }
            
            
            if (chunkHolder.childCount != 0)  DeleteTerrain();
            
            
            if (genMethod == GenerationMethod.Instantly) {
                for (int x = 0; x < WorldSizeInChunks; x++) {
                    for (int z = 0; z < WorldSizeInChunks; z++) {
                        Vector3Int chuckPos = new Vector3Int(x * chunkWidth, 0, z * chunkWidth);
                        chunks.Add(chuckPos, new Chunk(chuckPos, heightSmooth, heightMult, noiseType, smoothTerrain, flatShading,
                            useFallOff, heightCurve));
                        chunks[chuckPos].chuckObject.transform.SetParent(chunkHolder);
                        chunks[chuckPos].chuckObject.isStatic = true;
                    }
                }
            }else {
                StartCoroutine(Generate());
            }
        }
    }

    IEnumerator Generate() {
        for (int x = 0; x < WorldSizeInChunks; x++) {
            for (int z = 0; z < WorldSizeInChunks; z++) {
                Vector3Int chuckPos = new Vector3Int(x * chunkWidth, 0, z * chunkWidth);
                chunks.Add(chuckPos, new Chunk(chuckPos, heightSmooth, heightMult, noiseType, smoothTerrain, flatShading, useFallOff, heightCurve));
                chunks[chuckPos].chuckObject.transform.SetParent(chunkHolder);
                float time = GetTimeBetweenChunkGeneration();
                if (doDebug) _chunkLoadTimeText.text = "Time Between Chunk Loading: " + time;
                yield return new WaitForSeconds(time);
            }
        }
    }

    private void Update() {
        if (!MapGenerated && chunks.Count == WorldSizeInChunks * WorldSizeInChunks) {
            MapGenerated = true;
            Debug.Log("Map Generated");
            if (_chunkLoadTimeText != null) _chunkLoadTimeText.gameObject.SetActive(false);
        }
        
    }

    public void DeleteTerrain() {
        chunks.Clear();
        for (int i = 0; i < chunkHolder.childCount; i++) {
            DestroyImmediate(chunkHolder.GetChild(i).gameObject);
        }
        
        if (chunkHolder.childCount != 0)  DeleteTerrain();
    }
    
    float GetTimeBetweenChunkGeneration() {
        float mapSize = WorldSizeInChunks * WorldSizeInChunks;
        float fps = 1f / Time.deltaTime;
        float timeBetweenChunkGeneration = (mapSize / fps) / Time.frameCount;
        return timeBetweenChunkGeneration;
    }


    //Texture Generation - Only for Texture Generation mode
    void GenerateTexture(Renderer _r) {

        int width = _noiseMap.GetLength(0);
        int height = _noiseMap.GetLength(1);
        
        
        Texture2D _texture = new Texture2D(width, height);
        Color[] colorMap = new Color[width * height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (useFallOff)  _noiseMap[x, y] -=_falloffMap[x, y];
                
                
                colorMap[y * width + x] = Color.Lerp(Color.black, Color.white, _noiseMap[x,y]);
            }
        }

        _texture.SetPixels(colorMap);
        _texture.Apply();

        _r.sharedMaterial.mainTexture = _texture;
        _r.transform.localScale = new Vector3(_texture.width, 1, _texture.height) / 10;
    }
    
    
    //Terraforming - Not Tested (Might work)
    
    public void TerraformChunk(Vector3 centerPoint, float strength, float radius, bool placing) {
        List<Chunk> surroundingChunks = new List<Chunk>();
        
        List<Vector3Int> effectedVerts = new List<Vector3Int>();

        if (placing) {
            //transforms the position to usable point for the terrain map
            Vector3Int v3Int = new Vector3Int(Mathf.CeilToInt(centerPoint.x), Mathf.CeilToInt(centerPoint.y), Mathf.CeilToInt(centerPoint.z));
            effectedVerts.Add(v3Int);
            
            
            //Get the Chunks around // effectedChunks
            surroundingChunks.Add(chunks[new Vector3Int(v3Int.x, v3Int.y, v3Int.z + 1)]); // Forward
            surroundingChunks.Add(chunks[new Vector3Int(v3Int.x, v3Int.y, v3Int.z - 1)]); // backward
            surroundingChunks.Add(chunks[new Vector3Int(v3Int.x + 1, v3Int.y, v3Int.z)]); // Left
            surroundingChunks.Add(chunks[new Vector3Int(v3Int.x - 1, v3Int.y, v3Int.z)]); // Right
            
            //Get verts in radius
            for (int i = 0; i < chunks[v3Int].vertices.Count; i++) {
                if (Vector3.Distance(centerPoint, chunks[v3Int].vertices[i]) < radius) {
                    Vector3Int point = new Vector3Int(Mathf.CeilToInt(chunks[v3Int].vertices[i].x), Mathf.CeilToInt(chunks[v3Int].vertices[i].y), Mathf.CeilToInt(chunks[v3Int].vertices[i].z));
                    effectedVerts.Add(point);
                }
            }
            
            //Apply to all Verts in Radius
            for (int i = 0; i < effectedVerts.Count; i++) {
                Vector3Int point = effectedVerts[i];
                chunks[v3Int].terrainMap[point.x, point.y, point.z].dstToSurface *= strength;
            }
            
            
            chunks[v3Int].CreateMeshData();

            //Update surrounding chunks
            foreach (var chunk in surroundingChunks) {
                chunk.CreateMeshData();
            }
        }else {
            Vector3Int v3Int = new Vector3Int(Mathf.FloorToInt(centerPoint.x), Mathf.FloorToInt(centerPoint.y), Mathf.FloorToInt(centerPoint.z));
            
            //Updates chunks in a area
            foreach (var chunk in surroundingChunks) {
                chunk.terrainMap[v3Int.x, v3Int.y, v3Int.z].dstToSurface /= strength;
                chunk.CreateMeshData();
            }
        }
    }

    private void OnValidate() {
        if (oldgenType != genType) {
            oldgenType = genType;
            Texture = genType != GenerationType.Marching;
            Marching = genType == GenerationType.Marching;
            
            texturePlane.SetActive(Texture);
            chunkHolder.gameObject.SetActive(Marching);
        }
        if (oldnoiseType != noiseType) {
            oldnoiseType = noiseType;
            Complex = noiseType != NoiseType.Simple;
            Simple = noiseType == NoiseType.Simple;
        }

        if (autoUpdate && Texture) GenerateWorld();
    }
}

[CustomEditor(typeof(World))]
public class WorldEditor : Editor {
    private World _s;

    private void OnEnable()
    {
        _s = (World)target;
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Generate World")) {
            _s.GenerateWorld();
        }
        if (GUILayout.Button("Destory World")) {
            _s.DeleteTerrain();
        }

        base.OnInspectorGUI();
    }
}
