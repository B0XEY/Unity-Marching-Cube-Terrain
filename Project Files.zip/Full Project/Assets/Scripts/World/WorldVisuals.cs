using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Random = UnityEngine.Random;

public class WorldVisuals : MonoBehaviour
{
    public static WorldVisuals Instance { get; private set; }

    [Header("Planes")] 
    [SerializeField] private GameObject waterPlane;
    [SerializeField] private GameObject sandPlane;


    [Header("Terrain Material")] 
    [SerializeField] private Material _material;
    [SerializeField] private bool autoUpdate;
    [Space] 
    [SerializeField, ConditionalHide("showSeaLevel", true)] private float seaLevel;
    
    [HideInInspector] public bool showSeaLevel;

    public enum Mode {
        Biomes,
        Colors,
        SingleColor
    }

    [HideInInspector] public bool useBoth;
    public static bool useBiomes;
    [HideInInspector] public bool Color;
    [HideInInspector] public bool SingleColor;

    [Header("Shader Control")]
    [SerializeField] private Mode mode = Mode.Colors;
    private Mode oldmode = Mode.Colors;
    public static Mode currentmode = Mode.Colors;
    [Space] 
    [SerializeField, ConditionalHide("useBoth", true)] private DefaultBiome sand;
    [SerializeField, ConditionalHide("useBoth", true)] private DefaultBiome wall;
    [SerializeField, ConditionalHide("useBoth", true)] private DefaultBiome grass;
    [SerializeField] private Biome[] biomes;

    [SerializeField, ConditionalHide("SingleColor", true)] private Color color;
    [SerializeField, ConditionalHide("Color", true)] private Color grassColor;
    [SerializeField, ConditionalHide("Color", true)] private Color sandColor;
    [Space(2.5f)]
    [SerializeField, ConditionalHide("Color", true)] private bool useWallColor;
    [SerializeField, ConditionalHide("useWallColor", true)] private Color wallColor;


    [HideInInspector] public Texture2DArray texture2DArray;
    private List<Texture2D> textures = new List<Texture2D>();

    private Vector2 offset;

    private void Awake() {
        useBiomes = useBoth;
        if (Instance != null) {
            Destroy(Instance);
            Instance = null;
        }
        Instance = this;
        if (mode == Mode.Biomes)
        {
            offset = new Vector2(
                Random.Range(-999999, 999999),
                Random.Range(-999999, 999999)
            );
            HandleTextureArray();
        }
    }

    private void Start() {
        ApplyTextures();
    }

    public void ApplyTextures()
    {
        _material.SetFloat("num", 0);
        _material.SetFloat("_SeaLevel", seaLevel);
        if (mode == Mode.Biomes) {
            if (grass == null || wall == null || sand == null) {
                Debug.Log("Needed Biome(s) are not set");
                return;
            }
            _material.SetTexture("_SandTex",MixColorAndTexture(sand.textureColor, sand.texture));
            _material.SetTexture("_WallTex",MixColorAndTexture(wall.textureColor, wall.texture));
            _material.SetTexture("_GrassTex",MixColorAndTexture(grass.textureColor, grass.texture));
            
            if (biomes.Length > 0) _material.SetFloat("num", 1);
        }
        else if (mode == Mode.Colors) {
            _material.SetTexture("_GrassTex", MakeColorTexture(grassColor));
            _material.SetTexture("_WallTex",  useWallColor ? MakeColorTexture(wallColor) : MakeColorTexture(grassColor));
            _material.SetTexture("_SandTex", MakeColorTexture(sandColor));
        }
        else if (mode == Mode.SingleColor) 
        {
            _material.SetTexture("_GrassTex", MakeColorTexture(this.color));
            _material.SetTexture("_WallTex", MakeColorTexture(this.color));
            _material.SetTexture("_SandTex", MakeColorTexture(this.color));
        }
        
        //Water
        HandleObjects();
    }

    void HandleObjects() {
        Vector3 _pos = new Vector3(
            PositionMath.CalculateX(),
            seaLevel - .2f,
            PositionMath.CalculateZ()
        );
        
        waterPlane.transform.position = _pos;
        
        Vector3 _posSand = new Vector3(
            PositionMath.CalculateX(),
            0.5f,
            PositionMath.CalculateZ()
        );
        sandPlane.transform.position = _posSand;
        
        Vector3 _scale = new Vector3(
            World.WorldSizeInChunksS * 2,
            1,
            World.WorldSizeInChunksS * 2
        );
        waterPlane.transform.localScale = _scale * 8;
        sandPlane.transform.localScale = _scale * 8;
    }


    void HandleTextureArray() {
        textures.Add(MixColorAndTexture(sand.textureColor, sand.texture));
        textures.Add(MixColorAndTexture(grass.textureColor, grass.texture));

        for (int i = 0; i < biomes.Length; i++) {
            textures.Add(MixColorAndTexture(biomes[i].textureColor, biomes[i].texture));
        }
        
        texture2DArray = new Texture2DArray(512, 512, textures.Count, TextureFormat.ARGB32, false);


        for (int i = 0; i < textures.Count; i++)
        {
            texture2DArray.SetPixels(textures[i].GetPixels(0), i);
        }
        
        texture2DArray.Apply();
        _material.SetTexture("_WallTex", MixColorAndTexture(wall.textureColor, wall.texture));
        _material.SetTexture("_TexArr", texture2DArray);
        
        
    }

    public int GetTextureForPoint(Vector3 vertPos) {
        int point = 1;

        
        if (biomes.Length != 0) {
            point = 1;
            float perlinValue = Mathf.PerlinNoise(vertPos.x + offset.x, vertPos.z + offset.y);

            for (int i = 0; i < biomes.Length; i++) {
                if (perlinValue > biomes[i].heightRange.x && perlinValue < biomes[i].heightRange.y) point = i + 2;
                else point = i + 1;
            }
        }

        return point;
    }

    private Texture2D MakeColorTexture(Color _color) {
        Texture2D _temp = new Texture2D(1, 1);
        
        Color[] colorMap = new Color[1 * 1];
        for (int x = 0; x < 1; x++) {
            for (int y = 0; y < 1; y++) {
                colorMap[y * 1 + x] = _color;
            }
        }
        
        _temp.SetPixels(colorMap);
        _temp.Apply();

        return _temp;
    }
    
    private Texture2D MixColorAndTexture(Color _color, Texture2D _texture) {
        Texture2D _temp = new Texture2D(_texture.width, _texture.height);
        
        Color[] colorMap = new Color[_texture.width * _texture.height];
        for (int x = 0; x < _texture.width; x++) {
            for (int y = 0; y < _texture.height; y++) {
                Color textureColor = _texture.GetPixel(x, y);
                textureColor *= _color;
                colorMap[y * _texture.width + x] = textureColor;
            }
        }
        
        _temp.SetPixels(colorMap);
        _temp.Apply();

        return _temp;
    }
    
    private bool lastwallvalue;
    private void OnValidate() {
        currentmode = mode;
        if (oldmode != mode) {
            oldmode = mode;

            useBoth = mode == Mode.Biomes ? true : false;
            Color = mode == Mode.Colors ? true : false;
            SingleColor = mode == Mode.SingleColor ? true : false;
            
            showSeaLevel = mode != Mode.SingleColor;

            if (!Color) {
                lastwallvalue = useWallColor;
                useWallColor = false;
            }else if (useWallColor != lastwallvalue) {
                useWallColor = lastwallvalue;
            }
        }
        
        if (autoUpdate) ApplyTextures();
    }
}

[CustomEditor(typeof(WorldVisuals))]
public class WorldColorsEditor : Editor {
    private WorldVisuals _s;

    private void OnEnable()
    {
        _s = (WorldVisuals)target;
    }

    public override void OnInspectorGUI() {
        if (GUILayout.Button("Apply Colors")) {
            _s.ApplyTextures();
        }

        base.OnInspectorGUI();
    }
}

[Serializable]
public class Biome {
    [Header("Biome Info")] 
    [SerializeField] private string biomeName;
    public Vector2 heightRange;
    
    [Header("Texture Control")]
    public Texture2D texture;
    public Color textureColor;
}
[Serializable]
public class DefaultBiome {
    [Header("Texture Control")]
    public Texture2D texture;
    public Color textureColor;
}
