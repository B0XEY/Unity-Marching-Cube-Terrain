using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PerlinNoise {
    public static float[,] GenerateSimpleNoiseMap(int width, int height, float scale, int seed, Vector2 offset, bool timesHeight, float heightRange, float baseHeight, NormalizeMode mode, float normalizeScale) {
        float[,] NoiseMap = new float[width + 1, height + 1];
        
        System.Random prng = new System.Random(seed);
        float xOffset = prng.Next(-100000, 100000) + offset.x;
        float YOffset = prng.Next(-100000, 100000) - offset.y;
        Vector2 thisoffset = new Vector2(xOffset, YOffset);
        
        float maxPossibleHeight = 1f;
        
        float maxLocalNoiseHeight = float.MinValue;
        float minLocalNoiseHeight = float.MaxValue;

        
        float halfWidth = width / 2f;
        float halfHeight = height / 2f;

        for (int x = 0; x <= width; x++) {
            for (int y = 0; y <= height; y++)
            {
                float xCoord = (x - halfWidth + thisoffset.x) / scale;
                float yCoord = (y - halfHeight + thisoffset.y) / scale;

                float perlinValue = 0;
                
                if (timesHeight) perlinValue = heightRange * (Mathf.PerlinNoise(xCoord, yCoord) * 2 - 1) + baseHeight;
                else perlinValue = (Mathf.PerlinNoise(xCoord, yCoord) * 2 - 1) + baseHeight;

                if (perlinValue > maxLocalNoiseHeight)
                    maxLocalNoiseHeight = perlinValue;
                else if (perlinValue < minLocalNoiseHeight)
                    minLocalNoiseHeight = perlinValue;
                
                NoiseMap[x, y] = perlinValue;
            }
        }
        
        for (int x = 0; x <= width; x++) {
            for (int y = 0; y <= height; y++) {
                if (mode == NormalizeMode.Local) {
                    NoiseMap[x, y] = Mathf.InverseLerp(minLocalNoiseHeight, maxLocalNoiseHeight, NoiseMap[x, y]);
                }else {
                    float normalizedHeight = (NoiseMap[x, y] + 1) / (2f * maxPossibleHeight / normalizeScale);
                    NoiseMap[x, y] = Mathf.Clamp(normalizedHeight,0, int.MaxValue);
                }
            }
        }

        return NoiseMap;
    }
    
    public enum NormalizeMode {Local, Global}
    
    public static float[,] GenerateComplexNoiseMap(int width, int height, float scale, int seed, float _amplitude, float _frequency, int _octaves, float _persistence, float _lacunarity, Vector2 offset, bool timesHeight, float heightRange, float baseHeight, NormalizeMode mode, float normalizeScale) {
        float[,] NoiseMap = new float[width + 1, height + 1];
        
        float amplitude = _amplitude;
        float frequency = _frequency;
        
        float maxPossibleHeight = 0;

        System.Random prng = new System.Random(seed);
        Vector2[] octaveOffsets = new Vector2[_octaves];
        for (int i = 0; i < _octaves; i++) {
            float xOffset = prng.Next(-100000, 100000) + offset.x;
            float YOffset = prng.Next(-100000, 100000) - offset.y;
            octaveOffsets[i] = new Vector2(xOffset, YOffset);

            maxPossibleHeight += amplitude;
            amplitude *= _persistence;
        }
        
        
        float maxLocalNoiseHeight = float.MinValue;
        float minLocalNoiseHeight = float.MaxValue;
        
        float halfWidth = width / 2f;
        float halfHeight = height / 2f;
        
        
        for (int x = 0; x <= width; x++) {
            for (int y = 0; y <= height; y++) {
                amplitude = _amplitude;
                frequency = _frequency;
                
                float noiseHeight = 0;
                float perlinValue;
                
                
                for (int i = 0; i < _octaves; i++) {
                    float xCoord = (x - halfWidth + octaveOffsets[i].x) / scale * frequency;
                    float yCoord = (y - halfHeight - octaveOffsets[i].y) / scale * frequency;

                    if (timesHeight) perlinValue = heightRange * (Mathf.PerlinNoise(xCoord, yCoord) * 2 - 1) + baseHeight;
                    else perlinValue = (Mathf.PerlinNoise(xCoord, yCoord) * 2 - 1) + baseHeight;
                    noiseHeight += perlinValue * amplitude;

                    amplitude *= _persistence;
                    frequency *= _lacunarity;
                }

                if (noiseHeight > maxLocalNoiseHeight)
                    maxLocalNoiseHeight = noiseHeight;
                else if (noiseHeight < minLocalNoiseHeight)
                    minLocalNoiseHeight = noiseHeight;
                
                NoiseMap[x, y] = noiseHeight;
            }
        }

        for (int x = 0; x <= width; x++) {
            for (int y = 0; y <= height; y++) {
                if (mode == NormalizeMode.Local) {
                    NoiseMap[x, y] = Mathf.InverseLerp(minLocalNoiseHeight, maxLocalNoiseHeight, NoiseMap[x, y]);
                }else {
                    float normalizedHeight = (NoiseMap[x, y] + 1) / (2f * maxPossibleHeight / normalizeScale);
                    NoiseMap[x, y] = Mathf.Clamp(normalizedHeight,0, int.MaxValue);
                }
            }
        }

        return NoiseMap;
    }
    
    public static float[,] GenerateFalloffMap(int width, int height, float a, float b) {
        float[,] FalloffMap = new float[width + 1, height + 1];

        float sampleWidth = width + 1;
        float sampleHeight = height + 1;
        
        
        for (int x = 0; x <= width; x++) {
            for (int y = 0; y <= height; y++) {
                float sampleX = (float)x / sampleWidth * 2 - 1;
                float sampleY = (float)y / sampleHeight * 2 - 1;

                float value = Mathf.Max(Mathf.Abs(sampleX), Mathf.Abs(sampleY));
                FalloffMap[x, y] = Evaluate(value, a, b);
            }
        }

        return FalloffMap;
    }
    
    
    static float Evaluate(float value, float a, float b) {
        return Mathf.Pow(value, a) / (Mathf.Pow(value, a) + Mathf.Pow(b - b * value, a));
    }
    
    /* Function for desmos for visuals!
     *  f\left(x\right)\ =\ \frac{x^{a}}{x^{a}+\ \left(b-bx\right)^{a}}
     */
}
