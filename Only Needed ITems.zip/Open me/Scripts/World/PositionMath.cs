using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PositionMath {
    public static float CalculateX() {
        float temp = World.WorldSizeInChunksS * World.chunkWidthS;
        temp /= 2;

        return temp;
    }
    
    public static float CalculateZ() {
        float temp = World.WorldSizeInChunksS * World.chunkWidthS;
        temp /= 2;

        return temp;
    }
}
