using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEditor;
using UnityEngine;
using Random = UnityEngine.Random;

public class ObjectPlacer : MonoBehaviour
{
    [Header("Objects")] 
    [SerializeField] private GameObject grassObj;
    [SerializeField] private GameObject[] objectList;

    [Header("Settings")] 
    [SerializeField] private Material mat;
    [Space]
    [SerializeField] private Transform origin;
    [SerializeField] private GameObject objectHolder;
    [Space] 
    [SerializeField] private LayerMask placeLayer;
    [Space] 
    [SerializeField] private int numOfGrassPrefabs;
    [SerializeField] private int numOfPrefabs;
    [Space] 
    [SerializeField] private Vector2 rotationMinMaxXZ;
    [SerializeField] private Vector2 rotationMinMaxY;
    [SerializeField] private Vector2 scaleMinMax;
    

    public static bool startedSpawn;
    public static bool TreesSpawned;

    private float seaLevel;

    private void Start() {
        if (grassObj != null) numOfGrassPrefabs = (World.WorldSizeInChunksS * World.WorldSizeInChunksS) * 7;
        if (objectList.Length > 0) numOfPrefabs = (World.WorldSizeInChunksS * World.WorldSizeInChunksS) * 2;
        seaLevel = mat.GetFloat("_SeaLevel");
    }

    private void Update() {
        if (World.MapGenerated && !startedSpawn) {
            startedSpawn = true;
            if (grassObj != null) {
                for (int i = 0; i < numOfGrassPrefabs; i++) {
                    PlaceGrass();
                }
            }else {
                Debug.Log("Please put a grass Object in the 'grassObj' slot");
            }

            if (objectList.Length > 0) {
                for (int i = 0; i < numOfPrefabs; i++) {
                    PlaceObjects();
                }
            }else {
                Debug.Log("Please put a Object Prefab in the 'objectList'");
            }
        }
        if (objectList != null) TreesSpawned = true;
        if (startedSpawn && objectHolder.transform.childCount == numOfPrefabs && !TreesSpawned) {
            TreesSpawned = true;
            Debug.Log("Trees Spawned!");
        }
    }
    public void PlaceGrass() {
        Ray ray;
        RaycastHit hit;

        Vector3 oposition = new Vector3(
            Random.Range(0, PositionMath.CalculateX() * 2),
            64,
            Random.Range(0, PositionMath.CalculateZ() * 2)
        );
        
        origin.position = oposition;
        
        ray = new Ray(origin.position, Vector3.down);
        
        if (Physics.Raycast(ray, out hit, 100, placeLayer)) {
            if (hit.point.y > seaLevel + .45f) {
                GameObject obj = Instantiate(grassObj, hit.point, Quaternion.identity);
                obj.isStatic = true;
                
                obj.transform.SetParent(objectHolder.transform);
            
                var position = obj.transform.position;
                //position.y -= .5f;
                obj.transform.position = position;
            
                Vector3 scale = new Vector3(
                    Random.Range(scaleMinMax.x, scaleMinMax.y),
                    obj.transform.localScale.y,
                    Random.Range(scaleMinMax.x, scaleMinMax.y)
                );
                obj.transform.localScale = scale;
                
                obj.transform.rotation = Quaternion.FromToRotation(Vector3.up, hit.normal);


            }else
            {
                PlaceGrass();
            }
        }else {
            PlaceGrass();
        }
    }
    
    public void PlaceObjects() {
        Ray ray;
        RaycastHit hit;

        Vector3 oposition = new Vector3(
            Random.Range(0, PositionMath.CalculateX() * 2),
            64,
            Random.Range(0, PositionMath.CalculateZ() * 2)
        );
        
        origin.position = oposition;
        
        ray = new Ray(origin.position, Vector3.down);
        
        if (Physics.Raycast(ray, out hit, 100, placeLayer)) {
            if (hit.point.y > seaLevel + .35f) {
                int r = Random.Range(0, objectList.Length);
                GameObject obj = Instantiate(objectList[r], hit.point, Quaternion.identity);
                obj.isStatic = true;
                
                obj.transform.SetParent(objectHolder.transform);
            
                var position = obj.transform.position;
                position.y -= .65f;

                obj.transform.position = position;
            
                Vector3 scale = new Vector3(
                    Random.Range(scaleMinMax.x, scaleMinMax.y),
                    Random.Range(scaleMinMax.x, scaleMinMax.y),
                    Random.Range(scaleMinMax.x, scaleMinMax.y)
                );
                obj.transform.localScale = scale;
                
                obj.transform.rotation = Quaternion.FromToRotation(Vector3.up, hit.normal);
            
                Vector3 rotation = new Vector3(
                    Random.Range(rotationMinMaxXZ.x, rotationMinMaxXZ.y),
                    Random.Range(rotationMinMaxY.x, rotationMinMaxY.y),
                    Random.Range(rotationMinMaxXZ.x, rotationMinMaxXZ.y)
                );
                obj.transform.rotation = Quaternion.Euler(rotation);
            
            
            }else
            {
                PlaceObjects();
            }
        }else {
            PlaceObjects();
        }
    }
}

[CustomEditor(typeof(ObjectPlacer))]
public class ObjectPlacerEditor : Editor {
    private ObjectPlacer _s;

    private void OnEnable()
    {
        _s = (ObjectPlacer)target;
    }

    public override void OnInspectorGUI() {
        if (GUILayout.Button("Place Object")) {
            _s.PlaceObjects();
        }

        base.OnInspectorGUI();
    }
}
